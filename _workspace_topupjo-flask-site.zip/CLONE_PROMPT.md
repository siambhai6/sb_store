# 🎯 Topupjo.com Clone — Master Prompt

## 1. Project Overview
Build a **professional game top-up platform** (Free Fire diamonds, weekly/monthly membership, UID top-up, combo packages, lottery, etc.) for the Bangladesh market, inspired by **topupjo.com**. The site must be fully **dynamic**, driven by a database, with a complete **admin panel** so the owner can manage everything without touching code.

- **Stack:** Python 3.11 + Flask, Flask-SQLAlchemy (SQLite), Flask-Login, Jinja2 templates, vanilla CSS/JS, Pillow for image processing.
- **Language:** Bengali + English mixed UI (Bangla primary, English labels).
- **Currency:** BDT (৳).

## 2. Brand & Visual Design
- **Primary color:** `#db2d20` (brand red)
- **Accent / gold:** `#fbbf24`, `#fcd34d`
- **Dark:** `#0f172a`, **Surface:** `#ffffff`, **Soft bg:** `#fff7ed`
- **Fonts:** `Bree Serif` for headings, `Lato` / `Roboto` for body (Google Fonts).
- **Style:** Clean, modern, mobile-first, rounded cards (16–20px radius), soft shadows, red gradient header, gold badges, sticky top nav, bottom mobile nav, floating Telegram/help button.
- **Header:** Logo + site name | Topup | Contact Us | Login/Account.
- **Notice bar:** scrolling marquee with warning (18+ only, anti-fraud notice).
- **Footer:** Telegram HelpLine (8am–12am), About Us, Terms, Privacy, Refund, Delete Account, copyright.

## 3. Public Site Pages
### 3.1 Home
- Hero banner carousel (admin-managed banners) with CTA.
- Category chips/grid: 100% Bonus Topup, Lucky Weekly, Lucky Monthly, Mystery Box, Weekly Membership, Monthly Membership, Hot Offer, Lottery, UID Top Up, Weekly+Monthly Combo, Level Up Pass, Weekly Light, Big Package, Free Diamond Apps.
- Featured product cards with image, name, starting price, badge.
- **Live "Recent Orders" ticker** (name, product, price, time, ✓ Done).
- Trust section: 100% trusted, fast delivery, secure.
- Payment methods strip (bKash, Nagad, Rocket, etc.).
- Floating "সাহায্য লাগবে?" help button.

### 3.2 Topup Listing (`/topup`)
- Grid of all active products grouped/filterable by category, search box.

### 3.3 Product Detail (`/topup/<id>/<slug>`)
- Product image, title, description, "⚡ 2 সেকেন্ডে টপআপ".
- **Step 1 – Select Recharge:** package cards (e.g., Weekly ৳158, 2x ৳316 …).
- **Step 2 – Account Info:** Player ID / UID input.
- **Step 3 – Select payment:** Wallet Pay / Instant Pay (bKash/Nagad/etc.).
- Order summary with total; **Login to Purchase** if guest.
- Rules & Conditions accordion (Bangla order rules).
- On submit: create order (pending), deduct wallet if Wallet Pay.

### 3.4 Auth
- Login page: Google-style button placeholder, email + password, "Create an account".
- Register: name, email, phone, password.

### 3.5 User Dashboard
- Wallet balance, quick stats.
- My Orders (status: pending/completed/cancelled) + cancel own pending order.
- Deposit / Add Money (choose method, amount, txn id, sender number) → pending deposit.
- Deposit history.
- Profile edit.

### 3.6 Static pages
- About Us, Terms & Conditions, Privacy Policy, Refund & Return Policy, Delete Account Policy, Contact Us.

## 4. Admin Panel (`/admin`)
Secure login (separate admin credentials, password change).
- **Dashboard:** totals (users, orders, revenue, pending orders/deposits), recent orders, chart-ish stats.
- **Categories:** create / edit / delete (name, slug, description, image, sort, active).
- **Products:** create / edit / delete (category, name, slug, description, image, badge, sort, active).
- **Packages:** create / edit / delete (product, name, price, amount/diamonds, sort, active).
- **Payment Methods:** create / edit / delete (name, type wallet/instant, account number, instructions, logo, active).
- **Users:** list all users, search, view full history (orders + deposits), toggle block, adjust balance.
- **Orders:** all orders, filter by status, **Confirm** (complete) / **Cancel** (refund wallet if paid by wallet).
- **Deposits:** all deposits, filter, **Confirm** (credit wallet) / **Cancel**.
- **Banners:** manage hero banners.
- **Site Settings:** upload logo (auto-resize to max 512px, generate favicon sizes), change site name, tagline, **theme colors** (primary, accent, dark) applied live via CSS variables, contact info, currency, notice text.
- **Admin Password:** change password with current-password verification.

## 5. Functional Rules
- All content is DB-driven; deleting a category/product cascades safely.
- Wallet payments deduct balance atomically; cancelling refunds.
- Deposit confirmation credits wallet once (idempotent).
- Logo upload: accept png/jpg/webp, auto-resize with Pillow, store in `/static/uploads`.
- Theme colors stored in settings and injected into `<style>` as CSS variables.
- Flash messages for success/error; CSRF-safe forms.
- Responsive design; works on mobile.

## 6. Deliverables
- Complete Flask project runnable with `python app.py`.
- Seeded demo data (categories, products, packages, payment methods, admin user, demo user).
- Admin credentials documented.
- README with setup/run instructions.
