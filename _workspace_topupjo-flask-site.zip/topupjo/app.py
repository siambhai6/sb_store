import os
import uuid
from datetime import datetime
from functools import wraps

from flask import (Flask, abort, flash, redirect, render_template, request,
                   url_for)
from flask_login import (LoginManager, current_user, login_required,
                         login_user, logout_user)
from PIL import Image
from slugify import slugify
from werkzeug.utils import secure_filename

from config import Config
from models import (Banner, Category, Deposit, Order, Package, PaymentMethod,
                    Product, SiteSetting, User, db)

login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.login_message = "অর্ডার করতে অনুগ্রহ করে লগইন করুন।"
login_manager.login_message_category = "warning"


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------
def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in Config.ALLOWED_EXTENSIONS


def save_image(file, max_size=512):
    """Save an uploaded image, auto-resize keeping aspect ratio. Returns filename."""
    if not file or file.filename == "":
        return ""
    if not allowed_file(file.filename):
        return ""
    ext = file.filename.rsplit(".", 1)[1].lower()
    ext = "jpg" if ext == "jpeg" else ext
    filename = f"{uuid.uuid4().hex}.{ext}"
    path = os.path.join(Config.UPLOAD_FOLDER, filename)
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)
    img = Image.open(file)
    if img.mode in ("RGBA", "P") and ext == "jpg":
        img = img.convert("RGB")
    img.thumbnail((max_size, max_size), Image.LANCZOS)
    img.save(path, quality=88)
    return filename


def unique_slug(model, name, current_id=None):
    base = slugify(name) or f"item-{uuid.uuid4().hex[:6]}"
    slug = base
    i = 1
    while True:
        q = model.query.filter_by(slug=slug)
        if current_id:
            q = q.filter(model.id != current_id)
        if not q.first():
            return slug
        i += 1
        slug = f"{base}-{i}"


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash("অ্যাডমিন লগইন প্রয়োজন।", "warning")
            return redirect(url_for("admin_login", next=request.path))
        return f(*args, **kwargs)
    return decorated


# ----------------------------------------------------------------------------
# App factory
# ----------------------------------------------------------------------------
def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    # ---------------- Context processors ----------------
    @app.context_processor
    def inject_globals():
        settings = SiteSetting.all_dict()
        cats = Category.query.filter_by(active=True).order_by(Category.sort_order).all()
        return dict(
            settings=settings,
            nav_categories=cats,
            current_year=datetime.utcnow().year,
            now=datetime.utcnow(),
        )

    @app.template_filter("taka")
    def taka_filter(value):
        symbol = SiteSetting.get("currency", "৳") or "৳"
        try:
            return f"{symbol}{value:,.0f}"
        except (TypeError, ValueError):
            return f"{symbol}0"

    @app.template_filter("dt")
    def dt_filter(value, fmt="%d %b %Y, %I:%M %p"):
        return value.strftime(fmt) if value else ""

    # Valid CSS icon keys (see static/css/icons.css). Anything unknown falls
    # back to the gamepad icon so legacy/emoji values never break the UI.
    ICON_KEYS = {
        "bolt", "user", "menu", "phone", "mail", "clock", "heart", "home",
        "gamepad", "chat", "search", "shield", "money", "gem", "lock", "cart",
        "clipboard", "gift", "card", "box", "key", "chart", "folder", "image",
        "receipt", "wallet", "users", "gear", "globe", "logout", "save",
        "arrow", "arrow-left", "check", "close", "crown", "fire", "star",
        "spark", "info", "plus",
    }

    @app.template_filter("cat_icon")
    def cat_icon_filter(value):
        key = (value or "").strip().lower()
        return key if key in ICON_KEYS else "gamepad"

    # ========================================================================
    # PUBLIC ROUTES
    # ========================================================================
    @app.route("/")
    def home():
        banners = Banner.query.filter_by(active=True).order_by(Banner.sort_order).all()
        categories = Category.query.filter_by(active=True).order_by(Category.sort_order).all()
        products = (Product.query.filter_by(active=True)
                    .order_by(Product.sort_order).limit(12).all())
        recent = (Order.query.order_by(Order.created_at.desc()).limit(12).all())
        payments = PaymentMethod.query.filter_by(active=True).order_by(PaymentMethod.sort_order).all()
        return render_template("index.html", banners=banners, categories=categories,
                               products=products, recent=recent, payments=payments)

    @app.route("/topup")
    def topup():
        cat_slug = request.args.get("category", "")
        q = request.args.get("q", "").strip()
        query = Product.query.filter_by(active=True)
        active_cat = None
        if cat_slug:
            active_cat = Category.query.filter_by(slug=cat_slug).first()
            if active_cat:
                query = query.filter_by(category_id=active_cat.id)
        if q:
            query = query.filter(Product.name.ilike(f"%{q}%"))
        products = query.order_by(Product.sort_order).all()
        categories = Category.query.filter_by(active=True).order_by(Category.sort_order).all()
        return render_template("topup.html", products=products, categories=categories,
                               active_cat=active_cat, q=q)

    @app.route("/topup/<int:pid>/<slug>")
    def product_detail(pid, slug):
        product = db.session.get(Product, pid)
        if not product or not product.active:
            abort(404)
        packages = [p for p in product.packages if p.active]
        payments = PaymentMethod.query.filter_by(active=True).order_by(PaymentMethod.sort_order).all()
        related = (Product.query.filter(Product.category_id == product.category_id,
                                        Product.id != product.id, Product.active.is_(True))
                   .limit(4).all())
        return render_template("product.html", product=product, packages=packages,
                               payments=payments, related=related)

    @app.route("/order/place", methods=["POST"])
    @login_required
    def place_order():
        pid = request.form.get("product_id", type=int)
        pkg_id = request.form.get("package_id", type=int)
        player_id = request.form.get("player_id", "").strip()
        payment = request.form.get("payment_method", "Wallet")
        qty = max(1, request.form.get("quantity", 1, type=int))

        product = db.session.get(Product, pid)
        package = db.session.get(Package, pkg_id)
        if not product or not package or package.product_id != product.id:
            flash("অবৈধ প্রোডাক্ট বা প্যাকেজ।", "danger")
            return redirect(url_for("topup"))
        if not player_id:
            flash("Player ID / UID দিন।", "danger")
            return redirect(url_for("product_detail", pid=product.id, slug=product.slug))

        total = package.price * qty

        if payment == "Wallet":
            if current_user.balance < total:
                flash("আপনার ওয়ালেট ব্যালেন্স যথেষ্ট নয়। অনুগ্রহ করে ডিপোজিট করুন।", "danger")
                return redirect(url_for("dashboard"))
            current_user.balance -= total

        order = Order(user_id=current_user.id, product_id=product.id, package_id=package.id,
                      player_id=player_id, quantity=qty, unit_price=package.price,
                      total=total, payment_method=payment, status="pending")
        db.session.add(order)
        db.session.commit()
        flash("অর্ডার সফলভাবে জমা হয়েছে! শীঘ্রই প্রসেস করা হবে।", "success")
        return redirect(url_for("my_orders"))

    # ---------------- Auth ----------------
    @app.route("/login", methods=["GET", "POST"])
    def login():
        if current_user.is_authenticated:
            return redirect(url_for("home"))
        if request.method == "POST":
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")
            user = User.query.filter_by(email=email).first()
            if user and user.check_password(password):
                if user.is_blocked:
                    flash("আপনার অ্যাকাউন্ট ব্লক করা হয়েছে। সাপোর্টে যোগাযোগ করুন।", "danger")
                    return redirect(url_for("login"))
                login_user(user)
                flash(f"স্বাগতম, {user.name}!", "success")
                nxt = request.args.get("next")
                return redirect(nxt or url_for("home"))
            flash("ভুল ইমেইল বা পাসওয়ার্ড।", "danger")
        return render_template("login.html")

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if current_user.is_authenticated:
            return redirect(url_for("home"))
        if request.method == "POST":
            name = request.form.get("name", "").strip()
            email = request.form.get("email", "").strip().lower()
            phone = request.form.get("phone", "").strip()
            password = request.form.get("password", "")
            if not name or not email or len(password) < 6:
                flash("সব তথ্য দিন এবং পাসওয়ার্ড কমপক্ষে ৬ অক্ষর হতে হবে।", "danger")
                return redirect(url_for("register"))
            if User.query.filter_by(email=email).first():
                flash("এই ইমেইল দিয়ে ইতিমধ্যে অ্যাকাউন্ট আছে।", "danger")
                return redirect(url_for("login"))
            user = User(name=name, email=email, phone=phone, balance=0)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            login_user(user)
            flash("অ্যাকাউন্ট তৈরি সফল হয়েছে!", "success")
            return redirect(url_for("home"))
        return render_template("register.html")

    @app.route("/logout")
    @login_required
    def logout():
        logout_user()
        flash("আপনি লগআউট হয়েছেন।", "info")
        return redirect(url_for("home"))

    # ---------------- User dashboard ----------------
    @app.route("/dashboard")
    @login_required
    def dashboard():
        orders = (Order.query.filter_by(user_id=current_user.id)
                  .order_by(Order.created_at.desc()).limit(5).all())
        deposits = (Deposit.query.filter_by(user_id=current_user.id)
                    .order_by(Deposit.created_at.desc()).limit(5).all())
        stats = {
            "orders": Order.query.filter_by(user_id=current_user.id).count(),
            "completed": Order.query.filter_by(user_id=current_user.id, status="completed").count(),
            "pending": Order.query.filter_by(user_id=current_user.id, status="pending").count(),
        }
        payments = PaymentMethod.query.filter_by(active=True).order_by(PaymentMethod.sort_order).all()
        return render_template("dashboard.html", orders=orders, deposits=deposits,
                               stats=stats, payments=payments)

    @app.route("/dashboard/orders")
    @login_required
    def my_orders():
        orders = (Order.query.filter_by(user_id=current_user.id)
                  .order_by(Order.created_at.desc()).all())
        return render_template("orders.html", orders=orders)

    @app.route("/dashboard/deposits")
    @login_required
    def my_deposits():
        deposits = (Deposit.query.filter_by(user_id=current_user.id)
                    .order_by(Deposit.created_at.desc()).all())
        payments = PaymentMethod.query.filter_by(active=True).order_by(PaymentMethod.sort_order).all()
        return render_template("deposits.html", deposits=deposits, payments=payments)

    @app.route("/dashboard/profile", methods=["GET", "POST"])
    @login_required
    def profile():
        if request.method == "POST":
            current_user.name = request.form.get("name", current_user.name).strip()
            current_user.phone = request.form.get("phone", "").strip()
            new_pass = request.form.get("password", "")
            if new_pass:
                if len(new_pass) < 6:
                    flash("পাসওয়ার্ড কমপক্ষে ৬ অক্ষর হতে হবে।", "danger")
                    return redirect(url_for("profile"))
                current_user.set_password(new_pass)
            db.session.commit()
            flash("প্রোফাইল আপডেট হয়েছে।", "success")
            return redirect(url_for("profile"))
        return render_template("profile.html")

    @app.route("/order/<int:oid>/cancel", methods=["POST"])
    @login_required
    def cancel_my_order(oid):
        order = db.session.get(Order, oid)
        if not order or order.user_id != current_user.id:
            abort(404)
        if order.status != "pending":
            flash("এই অর্ডার আর বাতিল করা যাবে না।", "warning")
            return redirect(url_for("my_orders"))
        if order.payment_method == "Wallet":
            current_user.balance += order.total
        order.status = "cancelled"
        order.note = "ইউজার কর্তৃক বাতিল"
        db.session.commit()
        flash("অর্ডার বাতিল হয়েছে।", "info")
        return redirect(url_for("my_orders"))

    @app.route("/deposit", methods=["POST"])
    @login_required
    def create_deposit():
        amount = request.form.get("amount", type=float)
        method = request.form.get("method", "")
        txn_id = request.form.get("txn_id", "").strip()
        sender = request.form.get("sender_number", "").strip()
        if not amount or amount <= 0:
            flash("সঠিক পরিমাণ লিখুন।", "danger")
            return redirect(url_for("my_deposits"))
        dep = Deposit(user_id=current_user.id, amount=amount, method=method,
                      txn_id=txn_id, sender_number=sender, status="pending")
        db.session.add(dep)
        db.session.commit()
        flash("ডিপোজিট রিকোয়েস্ট জমা হয়েছে। অ্যাডমিন যাচাই করে অনুমোদন করবে।", "success")
        return redirect(url_for("my_deposits"))

    # ---------------- Static pages ----------------
    @app.route("/contactus")
    def contactus():
        return render_template("contact.html")

    @app.route("/about-us")
    def about():
        return render_template("page.html", title="About Us", page_key="about")

    @app.route("/terms-and-conditions")
    def terms():
        return render_template("page.html", title="Terms & Conditions", page_key="terms")

    @app.route("/privacy-policy")
    def privacy():
        return render_template("page.html", title="Privacy Policy", page_key="privacy")

    @app.route("/refund-return-policy")
    def refund():
        return render_template("page.html", title="Refund & Return Policy", page_key="refund")

    @app.route("/delete-account-policy")
    def delete_account():
        return render_template("page.html", title="Delete Account Policy", page_key="delete")

    # ========================================================================
    # ADMIN ROUTES
    # ========================================================================
    @app.route("/admin/login", methods=["GET", "POST"])
    def admin_login():
        if current_user.is_authenticated and current_user.is_admin:
            return redirect(url_for("admin_dashboard"))
        if request.method == "POST":
            email = request.form.get("email", "").strip().lower()
            password = request.form.get("password", "")
            user = User.query.filter_by(email=email, is_admin=True).first()
            if user and user.check_password(password):
                login_user(user)
                flash("অ্যাডমিন প্যানেলে স্বাগতম।", "success")
                return redirect(request.args.get("next") or url_for("admin_dashboard"))
            flash("ভুল অ্যাডমিন ক্রেডেনশিয়াল।", "danger")
        return render_template("admin/login.html")

    @app.route("/admin/logout")
    @login_required
    def admin_logout():
        logout_user()
        return redirect(url_for("admin_login"))

    @app.route("/admin/")
    @admin_required
    def admin_dashboard():
        stats = {
            "users": User.query.filter_by(is_admin=False).count(),
            "orders": Order.query.count(),
            "pending_orders": Order.query.filter_by(status="pending").count(),
            "completed_orders": Order.query.filter_by(status="completed").count(),
            "revenue": db.session.query(db.func.coalesce(db.func.sum(Order.total), 0))
                        .filter(Order.status == "completed").scalar(),
            "deposits": Deposit.query.count(),
            "pending_deposits": Deposit.query.filter_by(status="pending").count(),
            "products": Product.query.count(),
            "categories": Category.query.count(),
        }
        recent_orders = Order.query.order_by(Order.created_at.desc()).limit(8).all()
        recent_deposits = Deposit.query.order_by(Deposit.created_at.desc()).limit(5).all()
        return render_template("admin/dashboard.html", stats=stats,
                               recent_orders=recent_orders, recent_deposits=recent_deposits)

    # ---------------- Categories ----------------
    @app.route("/admin/categories")
    @admin_required
    def admin_categories():
        cats = Category.query.order_by(Category.sort_order).all()
        return render_template("admin/categories.html", categories=cats)

    @app.route("/admin/categories/new", methods=["GET", "POST"])
    @admin_required
    def admin_category_new():
        if request.method == "POST":
            name = request.form.get("name", "").strip()
            if not name:
                flash("নাম দিন।", "danger")
                return redirect(request.url)
            cat = Category(
                name=name,
                slug=unique_slug(Category, name),
                description=request.form.get("description", ""),
                icon=request.form.get("icon", "gamepad"),
                sort_order=request.form.get("sort_order", 0, type=int),
                active=bool(request.form.get("active")),
            )
            img = save_image(request.files.get("image"), 512)
            if img:
                cat.image = img
            db.session.add(cat)
            db.session.commit()
            flash("ক্যাটাগরি তৈরি হয়েছে।", "success")
            return redirect(url_for("admin_categories"))
        return render_template("admin/category_form.html", category=None)

    @app.route("/admin/categories/<int:cid>/edit", methods=["GET", "POST"])
    @admin_required
    def admin_category_edit(cid):
        cat = db.session.get(Category, cid) or abort(404)
        if request.method == "POST":
            cat.name = request.form.get("name", cat.name).strip()
            cat.slug = unique_slug(Category, cat.name, current_id=cat.id)
            cat.description = request.form.get("description", "")
            cat.icon = request.form.get("icon", "gamepad")
            cat.sort_order = request.form.get("sort_order", 0, type=int)
            cat.active = bool(request.form.get("active"))
            img = save_image(request.files.get("image"), 512)
            if img:
                cat.image = img
            db.session.commit()
            flash("ক্যাটাগরি আপডেট হয়েছে।", "success")
            return redirect(url_for("admin_categories"))
        return render_template("admin/category_form.html", category=cat)

    @app.route("/admin/categories/<int:cid>/delete", methods=["POST"])
    @admin_required
    def admin_category_delete(cid):
        cat = db.session.get(Category, cid) or abort(404)
        db.session.delete(cat)
        db.session.commit()
        flash("ক্যাটাগরি ডিলিট হয়েছে।", "info")
        return redirect(url_for("admin_categories"))

    # ---------------- Products ----------------
    @app.route("/admin/products")
    @admin_required
    def admin_products():
        products = Product.query.order_by(Product.sort_order).all()
        return render_template("admin/products.html", products=products)

    @app.route("/admin/products/new", methods=["GET", "POST"])
    @admin_required
    def admin_product_new():
        categories = Category.query.order_by(Category.sort_order).all()
        if request.method == "POST":
            name = request.form.get("name", "").strip()
            cat_id = request.form.get("category_id", type=int)
            if not name or not cat_id:
                flash("নাম ও ক্যাটাগরি দিন।", "danger")
                return redirect(request.url)
            p = Product(
                name=name, slug=unique_slug(Product, name), category_id=cat_id,
                description=request.form.get("description", ""),
                badge=request.form.get("badge", ""),
                sort_order=request.form.get("sort_order", 0, type=int),
                active=bool(request.form.get("active")),
            )
            img = save_image(request.files.get("image"), 640)
            if img:
                p.image = img
            db.session.add(p)
            db.session.commit()
            flash("প্রোডাক্ট তৈরি হয়েছে। এখন প্যাকেজ যোগ করুন।", "success")
            return redirect(url_for("admin_packages", product_id=p.id))
        return render_template("admin/product_form.html", product=None, categories=categories)

    @app.route("/admin/products/<int:pid>/edit", methods=["GET", "POST"])
    @admin_required
    def admin_product_edit(pid):
        p = db.session.get(Product, pid) or abort(404)
        categories = Category.query.order_by(Category.sort_order).all()
        if request.method == "POST":
            p.name = request.form.get("name", p.name).strip()
            p.slug = unique_slug(Product, p.name, current_id=p.id)
            p.category_id = request.form.get("category_id", p.category_id, type=int)
            p.description = request.form.get("description", "")
            p.badge = request.form.get("badge", "")
            p.sort_order = request.form.get("sort_order", 0, type=int)
            p.active = bool(request.form.get("active"))
            img = save_image(request.files.get("image"), 640)
            if img:
                p.image = img
            db.session.commit()
            flash("প্রোডাক্ট আপডেট হয়েছে।", "success")
            return redirect(url_for("admin_products"))
        return render_template("admin/product_form.html", product=p, categories=categories)

    @app.route("/admin/products/<int:pid>/delete", methods=["POST"])
    @admin_required
    def admin_product_delete(pid):
        p = db.session.get(Product, pid) or abort(404)
        db.session.delete(p)
        db.session.commit()
        flash("প্রোডাক্ট ডিলিট হয়েছে।", "info")
        return redirect(url_for("admin_products"))

    # ---------------- Packages ----------------
    @app.route("/admin/packages")
    @admin_required
    def admin_packages():
        product_id = request.args.get("product_id", type=int)
        query = Package.query
        product = None
        if product_id:
            product = db.session.get(Product, product_id)
            query = query.filter_by(product_id=product_id)
        packages = query.order_by(Package.product_id, Package.sort_order).all()
        products = Product.query.order_by(Product.name).all()
        return render_template("admin/packages.html", packages=packages,
                               products=products, product=product)

    @app.route("/admin/packages/new", methods=["GET", "POST"])
    @admin_required
    def admin_package_new():
        products = Product.query.order_by(Product.name).all()
        if request.method == "POST":
            product_id = request.form.get("product_id", type=int)
            name = request.form.get("name", "").strip()
            if not product_id or not name:
                flash("প্রোডাক্ট ও নাম দিন।", "danger")
                return redirect(request.url)
            pkg = Package(
                product_id=product_id, name=name,
                amount=request.form.get("amount", ""),
                price=request.form.get("price", 0, type=float),
                sort_order=request.form.get("sort_order", 0, type=int),
                active=bool(request.form.get("active")),
            )
            db.session.add(pkg)
            db.session.commit()
            flash("প্যাকেজ যোগ হয়েছে।", "success")
            return redirect(url_for("admin_packages", product_id=product_id))
        return render_template("admin/package_form.html", package=None, products=products)

    @app.route("/admin/packages/<int:pkid>/edit", methods=["GET", "POST"])
    @admin_required
    def admin_package_edit(pkid):
        pkg = db.session.get(Package, pkid) or abort(404)
        products = Product.query.order_by(Product.name).all()
        if request.method == "POST":
            pkg.product_id = request.form.get("product_id", pkg.product_id, type=int)
            pkg.name = request.form.get("name", pkg.name).strip()
            pkg.amount = request.form.get("amount", "")
            pkg.price = request.form.get("price", 0, type=float)
            pkg.sort_order = request.form.get("sort_order", 0, type=int)
            pkg.active = bool(request.form.get("active"))
            db.session.commit()
            flash("প্যাকেজ আপডেট হয়েছে।", "success")
            return redirect(url_for("admin_packages", product_id=pkg.product_id))
        return render_template("admin/package_form.html", package=pkg, products=products)

    @app.route("/admin/packages/<int:pkid>/delete", methods=["POST"])
    @admin_required
    def admin_package_delete(pkid):
        pkg = db.session.get(Package, pkid) or abort(404)
        pid = pkg.product_id
        db.session.delete(pkg)
        db.session.commit()
        flash("প্যাকেজ ডিলিট হয়েছে।", "info")
        return redirect(url_for("admin_packages", product_id=pid))

    # ---------------- Payment methods ----------------
    @app.route("/admin/payments")
    @admin_required
    def admin_payments():
        methods = PaymentMethod.query.order_by(PaymentMethod.sort_order).all()
        return render_template("admin/payments.html", methods=methods)

    @app.route("/admin/payments/new", methods=["GET", "POST"])
    @admin_required
    def admin_payment_new():
        if request.method == "POST":
            m = PaymentMethod(
                name=request.form.get("name", "").strip(),
                type=request.form.get("type", "instant"),
                account_number=request.form.get("account_number", ""),
                instructions=request.form.get("instructions", ""),
                color=request.form.get("color", "#db2d20"),
                sort_order=request.form.get("sort_order", 0, type=int),
                active=bool(request.form.get("active")),
            )
            img = save_image(request.files.get("logo"), 256)
            if img:
                m.logo = img
            db.session.add(m)
            db.session.commit()
            flash("পেমেন্ট মেথড যোগ হয়েছে।", "success")
            return redirect(url_for("admin_payments"))
        return render_template("admin/payment_form.html", method=None)

    @app.route("/admin/payments/<int:mid>/edit", methods=["GET", "POST"])
    @admin_required
    def admin_payment_edit(mid):
        m = db.session.get(PaymentMethod, mid) or abort(404)
        if request.method == "POST":
            m.name = request.form.get("name", m.name).strip()
            m.type = request.form.get("type", m.type)
            m.account_number = request.form.get("account_number", "")
            m.instructions = request.form.get("instructions", "")
            m.color = request.form.get("color", m.color)
            m.sort_order = request.form.get("sort_order", 0, type=int)
            m.active = bool(request.form.get("active"))
            img = save_image(request.files.get("logo"), 256)
            if img:
                m.logo = img
            db.session.commit()
            flash("পেমেন্ট মেথড আপডেট হয়েছে।", "success")
            return redirect(url_for("admin_payments"))
        return render_template("admin/payment_form.html", method=m)

    @app.route("/admin/payments/<int:mid>/delete", methods=["POST"])
    @admin_required
    def admin_payment_delete(mid):
        m = db.session.get(PaymentMethod, mid) or abort(404)
        db.session.delete(m)
        db.session.commit()
        flash("পেমেন্ট মেথড ডিলিট হয়েছে।", "info")
        return redirect(url_for("admin_payments"))

    # ---------------- Banners ----------------
    @app.route("/admin/banners", methods=["GET", "POST"])
    @admin_required
    def admin_banners():
        if request.method == "POST":
            b = Banner(
                title=request.form.get("title", ""),
                subtitle=request.form.get("subtitle", ""),
                link=request.form.get("link", "/topup"),
                sort_order=request.form.get("sort_order", 0, type=int),
                active=bool(request.form.get("active")),
            )
            img = save_image(request.files.get("image"), 1400)
            if img:
                b.image = img
            db.session.add(b)
            db.session.commit()
            flash("ব্যানার যোগ হয়েছে।", "success")
            return redirect(url_for("admin_banners"))
        banners = Banner.query.order_by(Banner.sort_order).all()
        return render_template("admin/banners.html", banners=banners)

    @app.route("/admin/banners/<int:bid>/delete", methods=["POST"])
    @admin_required
    def admin_banner_delete(bid):
        b = db.session.get(Banner, bid) or abort(404)
        db.session.delete(b)
        db.session.commit()
        flash("ব্যানার ডিলিট হয়েছে।", "info")
        return redirect(url_for("admin_banners"))

    # ---------------- Users ----------------
    @app.route("/admin/users")
    @admin_required
    def admin_users():
        q = request.args.get("q", "").strip()
        query = User.query.filter_by(is_admin=False)
        if q:
            query = query.filter(db.or_(User.name.ilike(f"%{q}%"), User.email.ilike(f"%{q}%")))
        users = query.order_by(User.created_at.desc()).all()
        return render_template("admin/users.html", users=users, q=q)

    @app.route("/admin/users/<int:uid>")
    @admin_required
    def admin_user_detail(uid):
        user = db.session.get(User, uid) or abort(404)
        orders = Order.query.filter_by(user_id=uid).order_by(Order.created_at.desc()).all()
        deposits = Deposit.query.filter_by(user_id=uid).order_by(Deposit.created_at.desc()).all()
        return render_template("admin/user_detail.html", user=user, orders=orders, deposits=deposits)

    @app.route("/admin/users/<int:uid>/toggle-block", methods=["POST"])
    @admin_required
    def admin_user_toggle(uid):
        user = db.session.get(User, uid) or abort(404)
        user.is_blocked = not user.is_blocked
        db.session.commit()
        flash("ইউজার স্ট্যাটাস পরিবর্তন হয়েছে।", "success")
        return redirect(url_for("admin_user_detail", uid=uid))

    @app.route("/admin/users/<int:uid>/balance", methods=["POST"])
    @admin_required
    def admin_user_balance(uid):
        user = db.session.get(User, uid) or abort(404)
        amount = request.form.get("amount", type=float)
        action = request.form.get("action", "add")
        if amount:
            if action == "add":
                user.balance += amount
            else:
                user.balance = max(0, user.balance - amount)
            db.session.commit()
            flash("ব্যালেন্স আপডেট হয়েছে।", "success")
        return redirect(url_for("admin_user_detail", uid=uid))

    # ---------------- Orders ----------------
    @app.route("/admin/orders")
    @admin_required
    def admin_orders():
        status = request.args.get("status", "")
        query = Order.query
        if status:
            query = query.filter_by(status=status)
        orders = query.order_by(Order.created_at.desc()).all()
        return render_template("admin/orders.html", orders=orders, status=status)

    @app.route("/admin/orders/<int:oid>/confirm", methods=["POST"])
    @admin_required
    def admin_order_confirm(oid):
        order = db.session.get(Order, oid) or abort(404)
        if order.status != "completed":
            order.status = "completed"
            db.session.commit()
            flash(f"অর্ডার #{order.id} কনফার্ম হয়েছে।", "success")
        return redirect(request.referrer or url_for("admin_orders"))

    @app.route("/admin/orders/<int:oid>/cancel", methods=["POST"])
    @admin_required
    def admin_order_cancel(oid):
        order = db.session.get(Order, oid) or abort(404)
        if order.status != "cancelled":
            if order.payment_method == "Wallet" and order.status != "completed":
                order.user.balance += order.total
            order.status = "cancelled"
            order.note = request.form.get("note", "অ্যাডমিন কর্তৃক বাতিল")
            db.session.commit()
            flash(f"অর্ডার #{order.id} বাতিল হয়েছে।", "info")
        return redirect(request.referrer or url_for("admin_orders"))

    # ---------------- Deposits ----------------
    @app.route("/admin/deposits")
    @admin_required
    def admin_deposits():
        status = request.args.get("status", "")
        query = Deposit.query
        if status:
            query = query.filter_by(status=status)
        deposits = query.order_by(Deposit.created_at.desc()).all()
        return render_template("admin/deposits.html", deposits=deposits, status=status)

    @app.route("/admin/deposits/<int:did>/confirm", methods=["POST"])
    @admin_required
    def admin_deposit_confirm(did):
        dep = db.session.get(Deposit, did) or abort(404)
        if dep.status != "approved":
            dep.user.balance += dep.amount
            dep.status = "approved"
            db.session.commit()
            flash(f"ডিপোজিট #{dep.id} অনুমোদিত হয়েছে এবং ব্যালেন্স যোগ হয়েছে।", "success")
        return redirect(request.referrer or url_for("admin_deposits"))

    @app.route("/admin/deposits/<int:did>/cancel", methods=["POST"])
    @admin_required
    def admin_deposit_cancel(did):
        dep = db.session.get(Deposit, did) or abort(404)
        if dep.status == "pending":
            dep.status = "rejected"
            db.session.commit()
            flash(f"ডিপোজিট #{dep.id} বাতিল হয়েছে।", "info")
        return redirect(request.referrer or url_for("admin_deposits"))

    # ---------------- Site settings ----------------
    @app.route("/admin/settings", methods=["GET", "POST"])
    @admin_required
    def admin_settings():
        if request.method == "POST":
            fields = ["site_name", "tagline", "primary_color", "accent_color", "dark_color",
                      "notice_text", "telegram", "phone", "email", "currency",
                      "footer_text", "about_text", "terms_text", "privacy_text",
                      "refund_text", "delete_text"]
            for f in fields:
                if f in request.form:
                    SiteSetting.set(f, request.form.get(f, ""))
            logo = save_image(request.files.get("logo"), 512)
            if logo:
                SiteSetting.set("logo", logo)
            favicon = save_image(request.files.get("favicon"), 192)
            if favicon:
                SiteSetting.set("favicon", favicon)
            flash("সাইট সেটিংস সংরক্ষণ হয়েছে।", "success")
            return redirect(url_for("admin_settings"))
        return render_template("admin/settings.html")

    @app.route("/admin/password", methods=["GET", "POST"])
    @admin_required
    def admin_password():
        if request.method == "POST":
            current = request.form.get("current_password", "")
            new = request.form.get("new_password", "")
            confirm = request.form.get("confirm_password", "")
            if not current_user.check_password(current):
                flash("বর্তমান পাসওয়ার্ড ভুল।", "danger")
            elif len(new) < 6:
                flash("নতুন পাসওয়ার্ড কমপক্ষে ৬ অক্ষর হতে হবে।", "danger")
            elif new != confirm:
                flash("নতুন পাসওয়ার্ড দুইবার একই হতে হবে।", "danger")
            else:
                current_user.set_password(new)
                db.session.commit()
                flash("অ্যাডমিন পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে।", "success")
                return redirect(url_for("admin_password"))
        return render_template("admin/password.html")

    @app.route("/favicon.ico")
    def favicon():
        fav = SiteSetting.get("favicon")
        if fav:
            return redirect(url_for("static", filename="uploads/" + fav))
        return redirect(url_for("static", filename="img/favicon.svg"))

    # ---------------- Error handlers ----------------
    @app.errorhandler(404)
    def not_found(e):
        return render_template("404.html"), 404

    return app


app = create_app()

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        try:
            from seed import seed_data
            seed_data()
        except Exception as exc:  # pragma: no cover
            print("Seed skipped:", exc)
    import os
    port = int(os.environ.get("PORT", 5001))
    app.run(host="0.0.0.0", port=port, debug=False)
