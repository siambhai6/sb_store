from datetime import datetime

from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

db = SQLAlchemy()


class User(UserMixin, db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(160), unique=True, nullable=False, index=True)
    phone = db.Column(db.String(40), default="")
    password_hash = db.Column(db.String(255), nullable=False)
    balance = db.Column(db.Float, default=0.0)
    is_admin = db.Column(db.Boolean, default=False)
    is_blocked = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    orders = db.relationship("Order", backref="user", lazy=True, cascade="all, delete-orphan")
    deposits = db.relationship("Deposit", backref="user", lazy=True, cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def total_spent(self):
        return sum(o.total for o in self.orders if o.status == "completed")

    def __repr__(self):
        return f"<User {self.email}>"


class Category(db.Model):
    __tablename__ = "categories"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False)
    slug = db.Column(db.String(180), unique=True, nullable=False)
    description = db.Column(db.Text, default="")
    image = db.Column(db.String(255), default="")
    icon = db.Column(db.String(16), default="gamepad")
    sort_order = db.Column(db.Integer, default=0)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    products = db.relationship("Product", backref="category", lazy=True, cascade="all, delete-orphan")


class Product(db.Model):
    __tablename__ = "products"
    id = db.Column(db.Integer, primary_key=True)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"), nullable=False)
    name = db.Column(db.String(200), nullable=False)
    slug = db.Column(db.String(220), unique=True, nullable=False)
    description = db.Column(db.Text, default="")
    image = db.Column(db.String(255), default="")
    badge = db.Column(db.String(60), default="")
    sort_order = db.Column(db.Integer, default=0)
    active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    packages = db.relationship("Package", backref="product", lazy=True, cascade="all, delete-orphan",
                               order_by="Package.sort_order")
    orders = db.relationship("Order", backref="product", lazy=True)

    @property
    def min_price(self):
        prices = [p.price for p in self.packages if p.active]
        return min(prices) if prices else 0


class Package(db.Model):
    __tablename__ = "packages"
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    name = db.Column(db.String(160), nullable=False)
    amount = db.Column(db.String(80), default="")
    price = db.Column(db.Float, nullable=False, default=0)
    sort_order = db.Column(db.Integer, default=0)
    active = db.Column(db.Boolean, default=True)


class PaymentMethod(db.Model):
    __tablename__ = "payment_methods"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    type = db.Column(db.String(20), default="instant")  # wallet / instant
    account_number = db.Column(db.String(80), default="")
    instructions = db.Column(db.Text, default="")
    logo = db.Column(db.String(255), default="")
    color = db.Column(db.String(20), default="#db2d20")
    sort_order = db.Column(db.Integer, default=0)
    active = db.Column(db.Boolean, default=True)


class Order(db.Model):
    __tablename__ = "orders"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    package_id = db.Column(db.Integer, db.ForeignKey("packages.id"))
    player_id = db.Column(db.String(120), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    unit_price = db.Column(db.Float, default=0)
    total = db.Column(db.Float, default=0)
    payment_method = db.Column(db.String(120), default="Wallet")
    status = db.Column(db.String(20), default="pending")  # pending / completed / cancelled
    note = db.Column(db.String(255), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    package = db.relationship("Package")

    @property
    def status_bn(self):
        return {"pending": "অপেক্ষমাণ", "completed": "সম্পন্ন", "cancelled": "বাতিল"}.get(self.status, self.status)


class Deposit(db.Model):
    __tablename__ = "deposits"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    amount = db.Column(db.Float, default=0)
    method = db.Column(db.String(120), default="")
    txn_id = db.Column(db.String(160), default="")
    sender_number = db.Column(db.String(60), default="")
    status = db.Column(db.String(20), default="pending")  # pending / approved / rejected
    note = db.Column(db.String(255), default="")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def status_bn(self):
        return {"pending": "অপেক্ষমাণ", "approved": "অনুমোদিত", "rejected": "বাতিল"}.get(self.status, self.status)


class Banner(db.Model):
    __tablename__ = "banners"
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), default="")
    subtitle = db.Column(db.String(255), default="")
    image = db.Column(db.String(255), default="")
    link = db.Column(db.String(255), default="/topup")
    sort_order = db.Column(db.Integer, default=0)
    active = db.Column(db.Boolean, default=True)


class SiteSetting(db.Model):
    __tablename__ = "site_settings"
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(80), unique=True, nullable=False)
    value = db.Column(db.Text, default="")

    @staticmethod
    def get(key, default=""):
        row = SiteSetting.query.filter_by(key=key).first()
        return row.value if row else default

    @staticmethod
    def set(key, value):
        row = SiteSetting.query.filter_by(key=key).first()
        if row:
            row.value = value
        else:
            db.session.add(SiteSetting(key=key, value=value))
        db.session.commit()

    @staticmethod
    def all_dict():
        return {r.key: r.value for r in SiteSetting.query.all()}
